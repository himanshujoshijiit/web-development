<?php

$set=mysqli_connect("localhost","root","","lms");
?>